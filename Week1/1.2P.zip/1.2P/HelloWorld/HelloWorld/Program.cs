﻿using System;

namespace HelloWorld
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Message myMessage;
            // Remove the first declaration of myNames to fix the error
            // Names myNames;

            myMessage = new Message("Hello World - From Message Object");
            myMessage.Print();

            Console.WriteLine("Please enter a name: ");
            string name = Console.ReadLine();

            // Now you can declare myNames and initialize it in the same line
            Names myNames = new Names(name);

            Console.ReadLine();
        }
    }
}
