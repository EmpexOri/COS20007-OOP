﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Names
    {

        private string _name;
        public Names(string name)
        {
            string[] namesList = { "Mark", "Fred", "Wilma", "Alice" };
            _name = name;
            _name = Console.ReadLine();

            if (namesList.Contains(name))
            {
                if (name == "Mark")
                {
                    Console.WriteLine("Welcome Back!");
                }
                else if (name == "Fred")
                {
                    Console.WriteLine("What a lovely name");
                }
                else if (name == "Wilma") 
                {
                    Console.WriteLine("Great name");
                }
                else if (name == "Alice")
                {
                    Console.WriteLine("Oh Hi!");
                }
            }
            if (!namesList.Contains(name)) // Check if the name is not present in the list
            {
                Console.WriteLine("That is a silly name");
            }
        }
    }
}
